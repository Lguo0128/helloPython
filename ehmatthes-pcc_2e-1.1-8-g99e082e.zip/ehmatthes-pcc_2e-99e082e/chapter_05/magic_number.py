answer = 17
if answer != 42:
    print("That is not the correct answer. Please try again!")
